//TODO: need to reset text input if selection is used.


function findMovie(){
//Code to check that only a string was entered in the text box.
	var userMovie = document.querySelector("#userTitle").value;
	
	function noSpecial(){
		var special = /[<|$]/g;
		if (userMovie.match(special)){
		    alert('Typed entry has to be spelled out in letters. No numbers or special characters accepted.');
	}};
	noSpecial();		

	
//Code to accept user input from form//	
	var starWars = document.querySelector("#selectTitle").value;
	var findMovie;
		if(userMovie != "eg. 'Wonder Woman'"){
			var manipMovie = userMovie.toLowerCase().split(" ");
			findMovie = manipMovie;
		} else{
			
			findMovie = starWars;
			
		};

//Code to send request to OMDB database//
	var dataTitle;
	var movDirector;
	var movPlot;
	var movCast;	
	var movPoster;
	
//Code to fetch movie information//	
	var info = 'http://www.omdbapi.com/?apikey=dd9a1de8&t=' + findMovie + '&y=&plot=full&r=json';
	
	fetch(info)
		.then(function(response) {return response.json();})
		.then(function(json) {
			dataTitle = json.Title;
			movDirector = json.Director;
			movPlot = json.Plot;
			movCast = json.Actors;
			movPoster = json.Poster;

			//jQuery to display movie poster//	
		$("#posterDisplay").html('<img src = "' + movPoster + '">');
			
	//jQuery to display information about user movie //	
		$("#userDisplay").html("<h1>Movie Title: " + dataTitle + "</h1>"
		+ "<h3> Director: " + movDirector + "</h3>" 
		+ "<h3>Actors/Actresses: " + movCast + "</h3>"
		+ "<p>Plot: " + movPlot + "</p>"
		);
		});			

}

function reTurn(){
	 $('#userTitle').val("eg. 'Wonder Woman'");
}

